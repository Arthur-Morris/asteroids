/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.Timer;
/**
 *
 * @author RP4K
 */
public class astroids extends Applet implements KeyListener, ActionListener 
{
    ArrayList <Astroid> astroidlist;
    ArrayList <bullet> bulletlist;
    ArrayList <deb> deblist;
    int[] x,y;
    int [] high = new int[11];
    String [] highname = new String[11];
    int L= 15,npx,npy, boostleft = 500,lastfired=-5, score = 0, lives = 5;
    boolean boost = false,up = true;
    ship ship;
    Timer timer;
    Image offscreen;
    Graphics offg;
    boolean upkey = false, leftkey = false, rightkey = false, shoot = false;
    /**
     * Initialization method that will be called after the applt is loaded
     * into the browser.e
     */
    public void init() 
    {
        astroidlist = new ArrayList();
        bulletlist = new ArrayList();
        deblist = new ArrayList();
        this.setSize(900,600);
        this.addKeyListener(this);
        timer = new Timer (20,this);
        offscreen = createImage(this.getWidth(),this.getWidth());
        offg = offscreen.getGraphics();
        for (int i = 0 ; i < 10 ; i++)
        {
            astroidlist.add(new Astroid());
        }
        ship = new ship(); 
        try
            {
                readhightscore();
            }
            catch(IOException ioe)
            {
                System.out.println (ioe);
            }
        // TODO start asynchronous download of heavy resources
    }
    public void start()
    {
        timer.start();
    }
    public void stop()
    {
        timer.stop();
    }
    // TODO overwrite start(), stop() and destroy() methods
    public void paint (Graphics g)
    {
        offg.setColor(Color.black);
        offg.fillRect(0, 0, 900, 600);
        if (astroidlist.isEmpty()== false)
        {
        if (ship.active)
            score += astroidlist.size();
            if ((upkey == true && ship.active)||(boost == true && ship.active && boostleft > 0))
            {
                L = 15;
                if (leftkey)
                {
                    L += 10;
                    offg.setColor(Color.red);
                }
                else
                    offg.setColor(Color.red);
                if (boost == true && boostleft > 0)
                {
                    offg.setColor(Color.blue);
                    L+=10;
                }
                npx = (int)Math.round((ship.drawshape.xpoints[4] - Math.cos (ship.angle)*L));
                npy = (int)Math.round((ship.drawshape.ypoints[4] - Math.sin (ship.angle)*L));
                offg.drawLine(ship.drawshape.xpoints[3], ship.drawshape.ypoints[3], npx, npy);
                offg.drawLine( npx ,npy ,ship.drawshape.xpoints[5], ship.drawshape.ypoints[5]); 
                L = 15;
                if (rightkey)
                {
                    L += 10;
                    offg.setColor(Color.red);
                }
                else
                    offg.setColor(Color.red);
                if (boost == true && boostleft > 0)            
                {
                    offg.setColor(Color.blue);
                    L+=10;
                }
                npx = (int)Math.round((ship.drawshape.xpoints[10] - Math.cos (ship.angle)*L));
                npy = (int)Math.round((ship.drawshape.ypoints[10] - Math.sin (ship.angle)*L));
                offg.drawLine(ship.drawshape.xpoints[9], ship.drawshape.ypoints[9], npx, npy);
                offg.drawLine( npx ,npy ,ship.drawshape.xpoints[11], ship.drawshape.ypoints[11]);
            }
            offg.setColor(Color.white);
            for (int i = 0 ;  i < bulletlist.size(); i++) 
            {
                bulletlist.get(i).paint(offg);
            }
            for (int i = 0 ;  i < astroidlist.size(); i++)
            {     
                offg.setColor(astroidlist.get(i).dcolor);
                astroidlist.get(i).paint(offg);
            }
            for (int i = 0 ;  i < deblist.size(); i++)
            {     
                offg.setColor(deblist.get(i).dcolor);
                deblist.get(i).paint(offg);
            }
            offg.setColor(Color.white);
            if (ship.active)
            {
                ship.paint(offg);
            }
            offg.drawString ("score : " + score + " |  boost : " + boostleft + " | lives left "+ lives ,5,15);
        }
        else
        {
            offg.setColor(Color.white); 
            offg.drawString ("your score was " + score,350,15);
            if (lives > 0)
                offg.drawString ("you win",350,35);
            else
                offg.drawString ("you fail",350,35);
            updated();
            try
            {
                Writehighscore();
            }
            catch(IOException ioe)
            {
                System.out.println (ioe);
            }
            offg.drawString ("highest scores",350,55);
            for (int r = 0,pl = 75; r < 10;r++)
            {
            offg.drawString (highname[r] + " = " + high[r],350,pl);
            pl +=20;
            }
        }
        g.drawImage(offscreen,0,0,this);
        repaint();
    }
    public void update (Graphics g)
    {
        paint (g);
    }
    @Override
    public void keyTyped(KeyEvent e) 
    { 
        
    }
    public void updated()
    {
        
        int t=9;
        if (up)
        {
            for (t = 9;t>=0;t--)
            {
                if (t == 0 && score > high[t])
                {
                    for (int l = 9,st=8;st >= t; l--)
                    {
                        
                        high[l] = high[st];
                        highname[l] = highname[st];
                        st-=1;
                    }
                    high[t] = score;
                    highname[t] = (String) JOptionPane.showInputDialog(null, "enter your name","window Title",JOptionPane.PLAIN_MESSAGE,null,null,"");
                    t = -1;
                }
                else if (score > high[t])
                {
                }
                else 
                {
                    if (t < 10)
                    {
                    t++;
                    for (int l = 10,st=9;st >= t;l--)
                    {
                        
                        high[l] = high[st];
                        highname[l] = highname[st];
                        st-=1;
                    }
                    high[t] = score;
                    highname[t] = (String) JOptionPane.showInputDialog(null, "enter your name","window Title",JOptionPane.PLAIN_MESSAGE,null,null,"");
                    t = -1;
                    }
                }
            }
        up = false;
        }
    }
    @Override
    public void keyPressed(KeyEvent e) 
    {                
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            rightkey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            leftkey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN)
        {
            boost = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            upkey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE)
        {
            shoot = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) 
    { 
        if (e.getKeyCode() == KeyEvent.VK_SPACE)
        {
            shoot = false;
        }
        else
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            rightkey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            leftkey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN)
        {
            boost = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            upkey = false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        checkkey();
        respawnShip();
        ship.updatePosition();
        for (int i = 0 ; i<astroidlist.size();i++)
        {
            astroidlist.get(i).updatePosition();
        }
        for (int i = 0 ; i < bulletlist.size();i++)
        {
            bulletlist.get(i).updatePosition(); 
              if (bulletlist.get(i).count > (Math.random ()*500) 
                    ||  bulletlist.get(i).active == false)
            {
                bulletlist.remove(i);
            }
        }for (int i = 0 ; i < deblist.size();i++)
        {
            deblist.get(i).updatePosition(); 
              if (deblist.get(i).count > (Math.random ()*500))
              {
                  deblist.remove(i);
              }
        }
        checkCollions();
        checkBoom();
    }
    public void checkkey()
    {
        if (rightkey == true)
        {
            ship.angle += 0.1; 
        }
        if (leftkey == true)
        {
            ship.angle -= 0.1; 
        }
        if (upkey == true)
        {
            ship.accelerate(0.1);
        }if (boost == true && boostleft > 0 && ship.active)
        {
            boostleft--;
            ship.accelerate(0.2);
        }
        
        if (shoot == true && ship.active && boost == false && lastfired <= ship.count)
        {
            bulletlist.add(new bullet(ship.drawshape.xpoints[1],ship.drawshape.ypoints[1],ship.angle));
            lastfired = ship.count +5;
        }
    }
    public boolean collision (VectorSprite thing1, VectorSprite thing2)
    {
        int x,y;
        for (int i = 0;i<thing1.drawshape.npoints;i++)
        {
            x = thing1.drawshape.xpoints[i];
            y = thing1.drawshape.ypoints[i];
            if (thing2.drawshape.contains (x,y))
            {
                return true;
            }
        }
        for (int i = 0;i < thing2.drawshape.npoints;i++)
        {
            x = thing2.drawshape.xpoints[i];
            y = thing2.drawshape.ypoints[i];
            if (thing1.drawshape.contains (x,y))
                return true;
        }       
        return false;
    }
    public void checkCollions()
    {
        for (int i = 0; i < astroidlist.size();i++)
        {
            if (collision (ship,astroidlist.get(i)))
            {
                ship.hit();
            }
            
            for(int c = 0;c < bulletlist.size();c++){
                
                if (collision (bulletlist.get(c),astroidlist.get(i)))
                {
                   
                        bulletlist.get(c).active=false;
                        astroidlist.get(i).active=false;
                        score += 200;
                    
                }
            }
        }
    }
    public void respawnShip ()
    {
        if (ship.active == false && ship.count >= 5 && isSafe() && lives > 0)
        {
            ship.reset();
            lives--;
            lastfired = -5;
        }
        else if (lives == 0)
        {
            for (int i = 0; i < astroidlist.size();i++)
            {
                astroidlist.remove(i);   
            }            
        }    
    }
   public boolean isSafe ()
   {
       int xa,ya,ha;
       for (int i = 0; i < astroidlist.size();i++)
       {
            xa = (int) astroidlist.get(i).xposition - 450;
            ya = (int) astroidlist.get(i).yposition - 300;
            ha = (int) Math.sqrt (xa*xa + ya*ya);
            if (ha <= 150)
                return false;            
        }
       return true;
   }
   public void checkBoom()
   {
       for (int i = 0; i < astroidlist.size();i++)
       {
           if(astroidlist.get(i).active == false)
           {
               if (astroidlist.get(i).size >1)
               {
                   astroidlist.add(new Astroid(astroidlist.get(i).xposition,astroidlist.get(i).yposition,astroidlist.get(i).size - 1));
                   astroidlist.add(new Astroid(astroidlist.get(i).xposition,astroidlist.get(i).yposition,astroidlist.get(i).size - 1));
               }
               for (int j = 0; j<8;j++)
               {
                   deblist.add(new deb(astroidlist.get(i).xposition,astroidlist.get(i).yposition,astroidlist.get(i).dcolor));
               }
               astroidlist.remove(i);
           }
       }
   }
   public void readhightscore () throws java.io.IOException
   {
       String temp;
       int start= 0,end=0,count = 0, pos = 0;
       FileReader fr = new FileReader("hightscore.txt");
       BufferedReader br = new BufferedReader(fr);
       temp = br.readLine();
	while (count < temp.length () && pos < high.length)
	{        
            if (temp.charAt (count) == '`' && count < temp.length ())
	    {
		start = ++count;
	    }

	    if (temp.charAt (count) == '~' && count < temp.length ())
	    {
		end = count;
                try
                {
                    high[pos]  = Integer.parseInt (temp.substring (start, end));
                    pos++;
                }
                catch(Exception e)
                {
		highname[pos]  = temp.substring (start, end);
                }
            }
	    count++;
	}
        br.close();
        fr.close();
   }
   public void Writehighscore()throws java.io.IOException
   {
       int pos=0;
       BufferedWriter bw = new BufferedWriter(new FileWriter("hightscore.txt",false));
       //FileWriter fw = new FileWriter("hightscore.txt",false);
       while (pos < 10) 
       {
       bw.write('`'+highname[pos]+"~`"+high[pos]+'~');
       pos ++;
       }
       bw.close();
   }
}      