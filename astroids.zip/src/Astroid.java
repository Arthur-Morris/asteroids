
import java.awt.Color;
import java.awt.Polygon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RP4K
 */
public class Astroid extends VectorSprite
{
    int size, score;
    Color dcolor = new Color((float)Math.random(),(float)Math.random(),(float)Math.random());
    public Astroid ()
    { 
        size = 3;
        start();
        active = true;
    }
    public Astroid (double x, double y,int s)
    { 
        size = s;
        start();
        xposition = x;
        yposition = y;
    }
    public void start ()
    {
        shape = new Polygon();
        shape.addPoint(10 * size, 1 * size);  
        shape.addPoint(2 * size, 12 * size);
        shape.addPoint(-8 * size, 3 * size);
        shape.addPoint(-6 * size, -5 * size);
        shape.addPoint(7 * size, -12 * size);
        drawshape = new Polygon();
        drawshape.addPoint(10 * size, 1 * size);  
        drawshape.addPoint(2 * size, 12 * size);
        drawshape.addPoint(-8 * size, 3 * size);
        drawshape.addPoint(-6 * size, -5 * size);
        drawshape.addPoint(7 * size, -12 * size);
        double h,a;
        h = Math.random()+1;
        a = Math.random()*2*Math.PI;
        xspeed = Math.cos(a)*h;
        yspeed = Math.sin(a)*h;
        h = Math.random()*400 + 150;
        a = Math.random()*2*Math.PI;
        active = true;
        xposition = Math.cos(a)*h+450;
        yposition = Math.cos(a)*h+450;
    }
    public void updatePosition()
    {
        angle += 0.1;
        super.updatePosition();
    }
}
