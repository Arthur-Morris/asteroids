
import java.awt.Color;
import java.awt.Polygon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RP4K
 */
public class deb extends VectorSprite
{
    Color dcolor;
    public deb (double x,double y,Color myc)
    {
        dcolor = myc;
        shape = new Polygon();
        shape.addPoint(0, 0);
        shape.addPoint(0, 0);
        drawshape = new Polygon();
        drawshape.addPoint(0, 0);
        drawshape.addPoint(0, 0);
        xposition = x;
        yposition = y;double h,a;
        h = Math.random()+1;
        a = Math.random()*2*Math.PI;
        xspeed = Math.cos(a)*h;
        yspeed = Math.sin(a)*h;
        
        active = true;
    } 
}