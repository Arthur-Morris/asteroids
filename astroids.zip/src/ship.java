
import java.awt.Polygon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RP4K
 */
public class ship extends VectorSprite
{
    public ship ()
    {
        shape = new Polygon();
        shape.addPoint(-10, -15);  
        shape.addPoint(20, 0);
        shape.addPoint(-10, 15);
        shape.addPoint(-7, 13);//flame one start
        shape.addPoint(-7, 9);
        shape.addPoint(-7, 5);//flame one stop
        shape.addPoint(-3, 5);
        shape.addPoint(0, 0);
        shape.addPoint(-3, -5);
        shape.addPoint(-7, -5);//flame two start
        shape.addPoint(-7, -9);
        shape.addPoint(-7, -13);//flame two stop
        drawshape = new Polygon();
        drawshape.addPoint(-10, -15);  
        drawshape.addPoint(20, 0);
        drawshape.addPoint(-10, 15);
        drawshape.addPoint(-7, 13);
        drawshape.addPoint(-7, 9);
        drawshape.addPoint(-7, 5);
        drawshape.addPoint(-3, 5);
        drawshape.addPoint(0, 0);
        drawshape.addPoint(-3, -5);
        drawshape.addPoint(-7, -5);
        drawshape.addPoint(-7, -9);
        drawshape.addPoint(-7, -13);
        active = true;
    }
    public void accelerate(double speed)
    {
        xspeed += Math.cos (angle)*speed;
        yspeed += Math.sin (angle)*speed;
    }
   public void reset()
   {
       xposition = 450;
       yposition = 300;
       xspeed = 0;
       yspeed = 0;
       angle = 0;
       active = true;
   }
   public void hit ()
   {
       active = false;
       count = 0;
   }
}
