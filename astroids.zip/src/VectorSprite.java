/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RP4K
 */
import java.awt.*;
public class VectorSprite 
{
    
    double xspeed, yspeed;
    double xposition = 450, yposition = 300;
    double angle;
    Polygon shape,drawshape;
    boolean active;
    int count;
    //int fax1 = -13,fay1 = -10,fax2 = -18,fay2 = -10,fbx1,fby1,fbx2,fby2;
    public void paint (Graphics g)
    {
        g.drawPolygon(drawshape);
    }
    public void updatePosition ()
    {
        xposition += xspeed;
        yposition += yspeed;
        count ++;
        wrap();
        int x,y;
        for (int i=0; i <drawshape.npoints;i++)
        {
            //.xpoints[i]+=xspeed;
            //shape.ypoints[i]+=yspeed;
            x = (int) Math.round (shape.xpoints[i]* Math.cos(angle)-shape.ypoints[i]*Math.sin(angle));
            y = (int) Math.round (shape.ypoints[i]* Math.cos(angle)+shape.xpoints[i]*Math.sin(angle));   
            drawshape.xpoints[i] = x;
            drawshape.ypoints[i] = y;
        }
        drawshape.invalidate();
        drawshape.translate( (int) xposition, (int) yposition);
    }
    private void wrap () 
    {
        if (xposition > 900)
            xposition = 0;
        if (xposition < 0)
            xposition = 900;
        
        if (yposition > 900)
            yposition = 0;
        if (yposition < 0)
            yposition = 900;
    }
}